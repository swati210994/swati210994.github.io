function varargout = finalgui(varargin)
% FINALGUI MATLAB code for finalgui.fig
%      FINALGUI, by itself, creates a new FINALGUI or raises the existing
%      singleton*.
%
%      H = FINALGUI returns the handle to a new FINALGUI or the handle to
%      the existing singleton*.
%
%      FINALGUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in FINALGUI.M with the given input arguments.
%
%      FINALGUI('Property','Value',...) creates a new FINALGUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before finalgui_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to finalgui_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help finalgui

% Last Modified by GUIDE v2.5 26-Aug-2018 09:35:02

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @finalgui_OpeningFcn, ...
                   'gui_OutputFcn',  @finalgui_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before finalgui is made visible.
function finalgui_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to finalgui (see VARARGIN)

% Choose default command line output for finalgui
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes finalgui wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = finalgui_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in gamma.
function gamma_Callback(hObject, eventdata, handles)
% hObject    handle to gamma (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global img                %img is the rgbtohsv transformed image
global lastimage         %lastimage is the globally defined variable to save the changes made to an image
lastimage=img;          %for undo last change we are saving the previous changes made

[m, n] = size(img);        %m=nunber of rows in image, n=number of columns in image

h=inputdlg('Input the gamma value');         %interactive dialog box to take input from user
g=str2num(h{1});            %conerting string value to number

out=(1*img).^g;        %g=gamma value, this is the expression to calculate gamma corrected image

axes(handles.axes2);        %specifying the image to be displayed in axes2 position       
imshow(out);            %displaying the gamma corrected image
img=out;        %storing the modified image in global variable so that further changes can be made on this image


% --- Executes on button press in verticaledgedetect.
function verticaledgedetect_Callback(hObject, eventdata, handles)
% hObject    handle to verticaledgedetect (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global img
global lastimage
lastimage=img;

[m, n]= size(img);

edge_kernel=[1 0 -1 ; 1 0 -1; 1 0 -1];    %prewitts edge detector kernel

A=img*255;        %img is the image modified into V value, V is in double so converting the value in range 0 to 255


for i=2:m-1             %loop to control rows
    for j=2:n-1         %loop to control columns
         o= A(i-1:i+1, j-1: j+1).*edge_kernel;        %convolution 
        d = sum(o(:));     %adding all the values dobtained after convolution
      out(i-1,j-1)=d;        %storing in the out image matrix
    end
end
out=out/255;     %dividing by 255 as we had multiplied with it before

axes(handles.axes2);
imshow(out);
img=out;


% --- Executes on button press in DFTmagnitudephase.
function DFTmagnitudephase_Callback(hObject, eventdata, handles)
% hObject    handle to DFTmagnitudephase (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global img

[m, n] = size(img);
freq_M        = zeros(m, m);        %defining m*m matrix of zeros
freq_N        = zeros(n, n);        %defining n*n matrix of zeros

for u = 0 : (m - 1)               %loop to control u frequency component in the dft expression
    for x = 0 : (m - 1)     %loop to control x spatial domain component of image
        freq_M(u+1, x+1) = exp(-2 * pi * 1i / m * x * u);     %calculating 1D dft in for x components  
    end    
end

for v = 0 : (n - 1)          %loop to control v frequency component in the dft expression
    for y = 0 : (n - 1)          %loop to control y spatial domain component of image
        freq_N(y+1, v+1) = exp(-2 * pi * 1i / n * y * v);       %calculating 1D dft in for y components
    end    
end

f = freq_M * img * freq_N;        %bringing together all the terms and calculating 2D DFT 

figure;

subplot(121),imagesc(100*log(1+abs(f))); colormap(gray);     %show log magnitude  
title('Magnitude spectrum');
subplot(122),imagesc(angle(f));  colormap(gray),title('Phase spectrum');      %show phase angle plot

% --- Executes on button press in log.
function log_Callback(hObject, eventdata, handles)
% hObject    handle to log (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global i         %i is the variable that stores the original image loaded by user
global img
global lastimage
lastimage=img;

im=rgb2gray(i);         
p=im2double(im);
[m, n]= size(p);

 y=inputdlg('Input the multiplier value');      %taking input for constant c from user
 c=str2double(y{1});    %converting string value to number

for k=1:m
    for j=1:n
        out(k,j) = c*log(1+ p(k,j));     %out saves the log transformed image
    end
end

axes(handles.axes2);
imshow(out);
img=out;

% --- Executes on button press in blurimage.
function blurimage_Callback(hObject, eventdata, handles)
% hObject    handle to blurimage (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global img
global lastimage
lastimage=img;

%lpf=(1/9)* [1 1 1 ; 1 1 1; 1 1 1];

p= im2double(img);

 y=inputdlg('Input the blur control value');        %to control extent of blurring we are accepting the value
 blurvalue=str2double(y{1});            
oddvalue = 2*blurvalue + 1;         %converting the value entered into a odd value(kernel should be a odd size matrix)

pad_size= floor((oddvalue-1)/2);        %calculating number of rows and columns to be appended to the image

imagepadding=padarray(p,[pad_size,pad_size],0,'both');    %padding the image
[m, n]= size(imagepadding);    %storing number of rows in m and columns in n

lpf = ones(oddvalue,oddvalue)./(oddvalue*oddvalue);    %generating the kernel(weighted average low pass filter)

for k=pad_size+1:m-pad_size
    for j=pad_size+1:n-pad_size
         o= imagepadding(k-pad_size:k+pad_size, j-pad_size: j+pad_size).*lpf;   %o stores the convolution values
        d = sum(o(:));    %summing up all the terms of convolution result
      out(k-pad_size,j-pad_size)=d;    %storing the values in image
    end
end

axes(handles.axes2);
imshow(out);
img=out;


% --- Executes on button press in sharpenimage.
function sharpenimage_Callback(hObject, eventdata, handles)
% hObject    handle to sharpenimage (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global img
global lastimage
lastimage=img;

slider_value=get(handles.sharpen_control,'Value');     %slider gives the value of extent of sharpening
imagepadding = padarray(img,[1,1],0,'both');    %padding the image

[m, n]= size(imagepadding);     %rows and columns of padded image in m and n resp.
hpf=[0 -1 0 ; -1 4+slider_value -1; 0 -1 0];      %defining the laplacian kernel(HPF)
%x=[0 0 0; 0 1 0; 0 0 0];
%hpf=x-lpf;
%lpga= 1/9 * lpf;
A=imagepadding*255;        %converting into range 0 to 255


for i=2:m-1
    for j=2:n-1
         o= A(i-1:i+1, j-1: j+1).*hpf;        %convolution
        d = sum(o(:));       %summing terms in convolution reult
      out(i-1,j-1)=d;    %storing in image matrix
    end
end
out=out/255;
Sharpened_image = out + img;     %adding the edges detected by kernel into original image to get a sharpened image
axes(handles.axes2);
imshow(Sharpened_image);
img=Sharpened_image;

% --- Executes on button press in histogram.
function histogram_Callback(hObject, eventdata, handles)
% hObject    handle to histogram (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global img
global lastimage
lastimage=img;

A=img*255;         
[m n]=size(A);
for k=0:255;
    ind=find(A==k);            %finding the frequency of each intensity level
    y=length(ind)/(m*n);        %finding probability of each intensity level
    c(k+1)=y;           %storing in particular index place, to show histogram
    s=sum(c(:));        
end

op=c;
csum=cumsum(op);       %calculting cumulative sum

for i=1:m
    for j=1:n
        h(i,j)=round(csum(A(i,j)+1)*255);       %equilizing the original image
    end
end
out=h/255;

[m n]=size(h);
for k=0:255;
    ind=find(h==k);         %finding the frequency of each intensity level
    y=length(ind)/(m*n);        %finding probability of each intensity level
    cumm(k+1)=y;         %storing in particular index place, to show histogram of equilized image
    s=sum(cumm(:));
end

po=cumm;
cummulativesum=cumsum(po);       %calculting cumulative sum
 
axes(handles.axes2);
imshow(out);
img=out;

figure;subplot(221),stem(c),title('Histogram of original image');
subplot(222),stem(csum),title('CDF of original image');
subplot(223),stem(cumm),title('Histogram of equilized image');
subplot(224),stem(cummulativesum),title('CDF of equilized image');

% --- Executes on button press in negativeimage.
function negativeimage_Callback(hObject, eventdata, handles)
% hObject    handle to negativeimage (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global img
global lastimage
lastimage=img;


p= img*255;            %p stores the values within img after converting in range 0 to 255
[m, n]= size(p);
for k=1:m
    for j=1:n
        out(k,j) = 255-p(k,j);         %formula used to convert into a negative image
    end
end
out=uint8(out);
%out=out/255;
axes(handles.axes2); 
imshow(out);
img=out;


% --- Executes on button press in loadimg.
function loadimg_Callback(hObject, eventdata, handles)
% hObject    handle to loadimg (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global i
[file path]= uigetfile('*.*', 'fileselector');          %creating a pop up for the user to select his/her image
image= strcat(path,file);            %concatenating the path and file names together
set(handles.imagepath,'String',image);      %displaying the whole path of image
i=imread(image);        %i is the original image selected by the user
axes(handles.axes1);
imshow(image);     %display original image

% --- Executes on button press in clrtohsv.
function clrtohsv_Callback(hObject, eventdata, handles)
% hObject    handle to clrtohsv (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global i
global img
a=rgb2hsv(i);         %converting rgb images to hsv
p=a(:,:,3);           %extracting third channel of the hsv converted image
axes(handles.axes2);
imshow(p);       %displaying hsv converted image
img=p;

% --- Executes on button press in saveimg.
function saveimg_Callback(hObject, eventdata, handles)
% hObject    handle to saveimg (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

[file path]= imsave(handles.axes2);           %user can select the destination to save modified image
% filename=string(file);
% pathname=string(path);
% modifiedimage_path = strcat(pathname,filename);
% display= msgbox(sprintf('The modified image has been saved in following loaction : ','String',modifiedimage_path));

% --- Executes on button press in undolast.
function undolast_Callback(hObject, eventdata, handles)
% hObject    handle to undolast (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global lastimage
global img
img =lastimage;              %goes back by one step, saving the last modified image(as mentioned in the comment of gamma callback)
axes(handles.axes2);          
imshow(img);           
%img=lastchange;

% --- Executes on button press in undoall.
function undoall_Callback(hObject, eventdata, handles)
% hObject    handle to undoall (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global i

axes(handles.axes2);
imshow(i);         %to undo all changes we are displaying the original image selected by the user



function imagepath_Callback(hObject, eventdata, handles)
% hObject    handle to imagepath (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of imagepath as text
%        str2double(get(hObject,'String')) returns contents of imagepath as a double


% --- Executes during object creation, after setting all properties.
function imagepath_CreateFcn(hObject, eventdata, handles)
% hObject    handle to imagepath (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function blurcontrol_Callback(hObject, eventdata, handles)
% hObject    handle to blurcontrol (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function blurcontrol_CreateFcn(hObject, eventdata, handles)
% hObject    handle to blurcontrol (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on button press in freq_mask.
function freq_mask_Callback(hObject, eventdata, handles)
% hObject    handle to freq_mask (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global img
global lastimage
lastimage=img;

[m, n]= size(img);
a=img*255;

dftofa = fft2(a);        %calculting dft of image

dftofa = fftshift(dftofa);      %fftshift=moving origin to image centre for display, shifted transform

figure,imshow(log(abs(dftofa)),[]);        %displaying in log scale

freq_filter = zeros(m,n);       %defining a m*n zeros matrix for further use
freq_filter((m/2)-50:(m/2)+50,(n/2)-70:(n/2)+70)=1;         %choosing the window size(kernel size)
figure,imshow(freq_filter,[]);     %displaying the window
 
freqd= freq_filter.*(log(abs(dftofa)));    %frequency domain display of the window
figure,imshow(freqd,[]);

filtered_output = dftofa.*freq_filter;        %frequency domain filtering

filtered_output = fftshift(filtered_output);       %shifted transform
 
out_image = real(ifft2(filtered_output));    %filtered image
axes(handles.axes2);
imshow(out_image,[]);
img=out_image;

% --- Executes on button press in horizontal_edge.
function horizontal_edge_Callback(hObject, eventdata, handles)
% hObject    handle to horizontal_edge (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global img
global lastimage
lastimage=img;

[m, n]= size(img);

hpf=[1 1 1 ; 0 0 0; -1 -1 -1];         %prewitts kernel to detect horizontal edges

A=img*255;


for i=2:m-1
    for j=2:n-1
         o= A(i-1:i+1, j-1: j+1).*hpf;          %convolution  
        d = sum(o(:));
      out(i-1,j-1)=d;
    end
end
out=out/255;

axes(handles.axes2);
imshow(out);
img=out;


% --- Executes on button press in gaussianfilter.
function gaussianfilter_Callback(hObject, eventdata, handles)
% hObject    handle to gaussianfilter (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global img
global lastimage
lastimage=img;

[m, n]= size(img);
a=img;

z=1;          %z=sigma value
for x=1:3
    for y=1:3
        i=(x-2)^2+(y-2)^2;
        G(x,y)=(1/(2*pi*(z^2)))*exp(-((i)/(2*(z^2))));          %formula of gaussian filter
    end
end


for i=2:m-1
    for j=2:n-1
         temp= img(i-1:i+1, j-1: j+1);
         o=temp.*G;          %converting the image using gaussian filter
        d = sum(o(:));
      out(i,j)=d;
    end
end

axes(handles.axes2);
imshow(out);
img=out;

% --------------------------------------------------------------------
function Untitled_1_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on slider movement.
function sharpen_control_Callback(hObject, eventdata, handles)
% hObject    handle to sharpen_control (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


%  this callback contains the same callback function as the sharpen image function  


global img
global lastimage
lastimage=img;

slider_value=get(handles.sharpen_control,'Value');            
imagepadding = padarray(img,[1,1],0,'both');

[m, n]= size(imagepadding);
hpf=[0 -1 0 ; -1 4+slider_value -1; 0 -1 0];
%x=[0 0 0; 0 1 0; 0 0 0];
%hpf=x-lpf;
%lpga= 1/9 * lpf;
A=imagepadding*255;


for i=2:m-1
    for j=2:n-1
         o= A(i-1:i+1, j-1: j+1).*hpf;
        d = sum(o(:));
      out(i-1,j-1)=d;
    end
end
out=out/255;
Sharpened_image = out + img;
axes(handles.axes2);
imshow(Sharpened_image);
img=Sharpened_image;

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function sharpen_control_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sharpen_control (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function blur_control_Callback(hObject, eventdata, handles)
% hObject    handle to blur_control (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function blur_control_CreateFcn(hObject, eventdata, handles)
% hObject    handle to blur_control (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end
