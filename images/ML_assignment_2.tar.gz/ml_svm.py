import numpy as np
from cvxopt import solvers
from cvxopt import matrix
import random
import csv

with open('./credit_card_data.csv', 'r') as csvFile:  #Import data file to a list
 data = list(csv.reader(csvFile,delimiter=','))

dataSamples = 200    #Total no of samples to be take from file
lengthTrain = 160    #No of training samples to be take from file
lengthTest = 40      #No of samples to be taken for testing of model
classSamples = int(dataSamples/2)       #No of samples to be take for each positie of negative class
trainSampLength = int(classSamples*0.8)  #No of samples for training from each positive or negative class

for dataframe in data:   #Remove time variable as removing it increases accuracy
    del dataframe[0]

n_columns = len(data.pop(0))  #Note down no of parameters for training and also remove the lables of parameters
arrAccuracy = np.zeros(5)     #Create an empty array for storing accuracies in each iteration        
posSamples = []               #Create an empty list for storing positive samples from data
negSamples = []               #Create an empty list for storing negative samples from data

for i in range(len(data)):            #Label the samples as positive or negative for convenience of SVM equations
    if data[i][(len(data[0])-1)] == '1':
        data[i][(len(data[0])-1)] = '-1'
        posSamples.append(data[i])
    elif data[i][(len(data[0])-1)] == '0':
        data[i][(len(data[0])-1)] = '1'
        negSamples.append(data[i])

for k in range(5):                                    #Train and test 5 times taking random samples from data file
   
    posSamp = random.sample(posSamples,classSamples)        #Take samples for training and testing from positive samples
    negSamp = random.sample(negSamples,classSamples)        #Take samples for training and testing from negative samples


    posSampTrain = np.asarray((posSamp[0:trainSampLength]),dtype='float64') #Convert the lists to numpy array for processing
    negSampTrain = np.asarray((negSamp[0:trainSampLength]),dtype='float64')

    trainMatrixPos = posSampTrain[:,0:(n_columns-1)]    #Separate training parameters and Class output into matrices
    trainMatrixNeg = negSampTrain[:,0:(n_columns-1)]
    classMatrixPos = posSampTrain[:,(n_columns-1)]
    classMatrixNeg = negSampTrain[:,(n_columns-1)]
    
    testPosSamp = np.asarray((posSamp[trainSampLength:classSamples]),dtype='float64') #Convert the lists to numpy array for processing of test data
    testNegSamp = np.asarray((negSamp[trainSampLength:classSamples]),dtype='float64')

    trainData = np.concatenate((negSampTrain,posSampTrain),axis=0)  #Join positive and negative samples to get a matrix
    testData =  np.concatenate((testNegSamp,testPosSamp),axis=0)
    
    xMatrixTr = trainData[:,0:(n_columns-1)]            #Separate train and test matrices to training parameters and output class variable
    xMatrixTe = testData[:,0:(n_columns-1)]
    yMatrixTr = trainData[:,(n_columns-1)]
    yMatrixTe = testData[:,(n_columns-1)]

    h = np.zeros(lengthTrain)              #create h matrix for giving to cvxopt for constraint alpha >=0
    b = matrix(np.zeros(1))                        #
    A = yMatrixTr 
    q = (-1)*(np.ones(lengthTrain))
    G = -1*(np.identity(lengthTrain))
    P = np.zeros((lengthTrain,lengthTrain))     #Create an empty matrix for storing values for P
    w = np.zeros(n_columns-1)     #Empty vector for storing values of hypothese matrix w

    for i in range(lengthTrain):                #Calculate the values of Matrix P
        for j in range(lengthTrain):
            P[i][j] = yMatrixTr[i]*yMatrixTr[j]*(np.matmul((xMatrixTr[i]).T,xMatrixTr[j]))

    sol_opt = solvers.qp(matrix(P),matrix(q),matrix(G),matrix(h),matrix(A.reshape(1,lengthTrain)),b) #Obtain optimum solution using cvxopt

    alpha = np.asarray(sol_opt['x'],dtype='float64') #Get values of alpha from obtained optimum solution
    
    for i in range(lengthTrain):   #Calculate w using aphaas
        w = w + (alpha[i])*(yMatrixTr[i])*(xMatrixTr[i])

    sv_mat_p = np.matmul(trainMatrixPos,w)       #Intermediate calculations for hypothesis parameter b
    sv_mat_n = np.matmul(trainMatrixNeg,w)
    
    c = (-(1/2))*(np.max(sv_mat_p)+np.min(sv_mat_n)) #get hypothesis parameter b in eq wx + b
 
    ySVMOut = [x + c for x in np.matmul(xMatrixTe,w)]   #Get output of SVM for tese data

    for i in range(len(ySVMOut)):              #Threshold the values to get positive or negative outputs
       if ySVMOut[i] <= 0:
           ySVMOut[i] = -1
       elif ySVMOut[i]>0:
           ySVMOut[i]= 1
     
    matches = 0                                #Empty variable for storing values of no of correct outputs of SVM

    for i in range(len(ySVMOut)):              #Calculate the no. of right output of SVM
        if ySVMOut[i] == yMatrixTe[i]:
            matches +=1

    arrAccuracy[k] = (matches/lengthTest)*100   #Calculate Accuracy


print(arrAccuracy)                   #Print the obtained accuracies and average accuracy
print("Average accuracy is  :")
print(np.sum(arrAccuracy)/5)