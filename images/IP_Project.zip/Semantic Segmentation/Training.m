inputSize = [150 150 3];
imgLayer = imageInputLayer(inputSize);
filterSize = 3;
numFilters = 2;
conv = convolution2dLayer(filterSize,numFilters,'Padding',1);
relu = reluLayer();
poolSize = 2;
maxPoolDownsample2x = maxPooling2dLayer(poolSize,'Stride',2);
downsamplingLayers = [
    conv
    relu
    maxPoolDownsample2x
    conv
    relu
    maxPoolDownsample2x
    ];
filterSize = 4;
transposedConvUpsample2x = transposedConv2dLayer(4,numFilters,'Stride',2,'Cropping',1);
upsamplingLayers = [
    transposedConvUpsample2x
    relu
    transposedConvUpsample2x
    relu
    ];
numClasses = 3;
conv1x1 = convolution2dLayer(1,numClasses);
finalLayers = [
    conv1x1
    softmaxLayer()
    pixelClassificationLayer()
    ];
net = [
    imgLayer    
    downsamplingLayers
    upsamplingLayers
    finalLayers
    ];
dataSetDir = fullfile('C:\Users\saurb\OneDrive\Documents\MATLAB\local\MyProject\+vision\+labeler','Pothole Image Dataset');
imageDir = fullfile(dataSetDir,'TrainingImages');
labelDir = fullfile(dataSetDir,'PixelLabelData');
imds = imageDatastore(imageDir);
classNames = ["pothole","background"];
labelIDs   = [1 0];
pxds = pixelLabelDatastore(labelDir,classNames,labelIDs);

I = read(imds);
C = read(pxds);
L = uint8(C);
figure(1);
imshowpair(I,L,'montage')

reset(pxds);

numFilters = 2;
filterSize = 3;
numClasses = 2;
layers = [
    imageInputLayer([300 300 3])
    convolution2dLayer(filterSize,numFilters,'Padding',1)
    reluLayer()
    maxPooling2dLayer(2,'Stride',2)
    convolution2dLayer(filterSize,numFilters,'Padding',1)
    reluLayer()
    transposedConv2dLayer(4,numFilters,'Stride',2,'Cropping',1);
    convolution2dLayer(1,numClasses);
    softmaxLayer()
    pixelClassificationLayer()
    ];
opts = trainingOptions('sgdm', ...
    'InitialLearnRate',1e-3, ...
    'MaxEpochs',50, ...
    'MiniBatchSize',300);
trainingData = pixelLabelImageDatastore(imds,pxds);
net = trainNetwork(trainingData,layers,opts);
testImage = imread('C:\Users\saurb\OneDrive\Documents\MATLAB\local\MyProject\+vision\+labeler\Pothole Image Dataset\TestingImages\1_img.jpg');
figure(2);
imshow(testImage);
C = semanticseg(testImage,net);
B = labeloverlay(testImage,C);
figure(3);
imshow(B)
tbl = countEachLabel(trainingData);
totalNumberOfPixels = sum(tbl.PixelCount);
frequency = tbl.PixelCount / totalNumberOfPixels;
classWeights = 1./frequency
layers(end) = pixelClassificationLayer('Classes',tbl.Name,'ClassWeights',classWeights);
net = trainNetwork(trainingData,layers,opts);
C = semanticseg(testImage,net);
B = labeloverlay(testImage,C);
figure(4);
imshow(B)