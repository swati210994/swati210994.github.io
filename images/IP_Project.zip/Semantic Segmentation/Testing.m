 net = load('training_network.mat');
 net = net.net;
 testImage = imread('C:\Users\saurb\OneDrive\Documents\MATLAB\local\MyProject\+vision\+labeler\Pothole Image Dataset\TestingImages\30_90_img.jpg');
 figure(1);
 imshow(testImage)
 C = semanticseg(testImage,net);
 B = labeloverlay(testImage,C);
 figure(2);
 imshow(B)