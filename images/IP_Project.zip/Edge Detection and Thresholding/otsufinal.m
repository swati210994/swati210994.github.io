clc;
clear all;
close all;
a=imread('E:\ip codes\project\images.jpg');
a = rgb2gray(a);
subplot(2,2,1);imshow(a);title('Original image');
[m n]=size(a);
for k=0:255
    ind=find(a==k);
    y=length(ind)/(m*n);
    c(k+1)=y;
    s=sum(c(:));
end
subplot(2,2,2);plot(0:255,c);title('Histogram');

ut=sum((1:256).*c(1:end));
for t=1:256;
    
    w0=max(0.0001,sum(c(1:t)));
    w1=max(0.0001,sum(c(t+1:end)));
    %w2=sum(c(t+1:end))
    u0=((sum((1:t).*c(1:t)))/w0);  
    u1=((sum((t+1:256).*c(t+1:end)))/w1);
    v=(w0+w1);
    v1=(w0*u0)+(w1*u1);
    cc=((u0-u1)*(u0-u1));
    var(t)=(w0)*(w1)*(cc);
end
varsq=max(var(:));
subplot(2,2,3);
stem(var);
title('plot of variance');
[val ind]=max(var);
y=ind;
ind=find(a<y);
a(ind)=0;
ind=find(a>=y);
a(ind)=1;
subplot(2,2,4);
imagesc(a);
colormap gray;
title('Segmented image of pothole');
