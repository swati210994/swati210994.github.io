close all;
I=imread('E:\ip codes\project\test1.jpg');
figure,subplot(1,3,1);
imshow(I);
title('original image');
I1=rgb2gray(I);
% h=imhist(I1);
% stem(h);
% figure,
% title('histogram of the image');
%histogram equalisation
% im2=histeq(I1);
% figure,
% imshow(im2);
% title('equalized image');
% imhist(im2);
[H,W]=size(I1);
[hist x]=imhist(I1);
subplot(1,3,2);
imhist(I1);
title('histogram of the image');
%converting to probability
p=hist/(H*W);
t=128; %initial guess of threshold
while true
    disp(t);
    m1 = (x>t); % group 1
    u1=sum(x(m1).*p(m1))/sum(p(m1)); %mean of group 1
    m2 = (x<=t); %group 2
    u2= sum(x(m2).*p(m2))/sum(p(m2));
    tnew= (u1+u2)/2;
    if t==tnew
        break;
    else
        t=tnew;
    end
end
t=130;
I_th=im2bw(I1,t/255);
subplot(1,3,3);
imshow(I_th);
    




