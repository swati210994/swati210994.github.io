import numpy as np 
import pandas as pd
from scipy.io import loadmat

indianpinesData = loadmat('Indian_pines_corrected.mat') #Load image data from mat file into dictionary indianpinesData.
groundtruthData = loadmat('Indian_pines_gt.mat') #Load groundtruth data from mat file into dictionary.

#Below line of code attaches groundtruth data from groundtruth file with the respective pixels locations of pines image.
pinesData = np.dstack(((np.array(indianpinesData["indian_pines_corrected"])),(np.array(groundtruthData["indian_pines_gt"]))))
pinesDataframe = pd.DataFrame(pinesData[:,0,:]) #Create a pandas dataframe initializing with data from first column of image file.

for i in range(len(pinesData[0,:,0])-1): #Convert pixel data from all 145 planes or columns to a linear dataframe for processing
    pinesDataframe = pinesDataframe.append(pd.DataFrame(pinesData[:,i+1,:]),ignore_index=True)

noOfClasses = 16 #No of classes in data
alpha = 0.075    #Learning Rate
n_iterations_gd = 21000 #No of iterations to be used for gradient descent

dataframeTest = pd.DataFrame(columns=pinesDataframe.columns) #Declare dataframe to be used for storing training data
dataframeTrain = pd.DataFrame(columns=pinesDataframe.columns) #Declare dataframe to be used for storing model test data

dataFrame1 = (pinesDataframe.sort_values(200,ascending=True)) #Sort the values in dataframe by class no for observing the values

dframeLabels = dataFrame1[200] #Extract labels information from dataframe containing all of the image data
dflabelArray = np.array(dframeLabels) #convert labels vector to a numpy array for processing
dfarrayData = np.array(dataFrame1.drop(200,axis = 1)) #Extract features only data removing class labels
dfnormal = (dfarrayData - dfarrayData.mean(axis = 0)) / (dfarrayData.std(axis = 0)) #Normalize the features matrix
dfPines = pd.concat((pd.DataFrame(dfnormal),pd.DataFrame(dflabelArray,columns=[200])),axis=1) #Attach labels to normalized features

for i in range(16): #For 16 classes of data take half of the samples of each class into training and other half into test dataframe
    n_sampHalf = (int)(((dfPines.loc[dfPines[200]==i+1])[0].count())/2) #Half the no of samples in each class
    samples_i = (dfPines.loc[dfPines[200]==i+1]) #Take all the samples of a given class
    samples_i = samples_i.sample(frac=1) #Randomly shuffle the samples of a given class
    samples_i2 = samples_i[:n_sampHalf+2] #Take half of the randomly shuffled samples of a class in training data
    samples_i3 = samples_i[n_sampHalf+2:] #Take remaining half of the randomly shuffled samples of a class in test data
    dataframeTrain = dataframeTrain.append(samples_i2) #Add the training samples of a class to training dataframe
    dataframeTest = dataframeTest.append(samples_i3)  #Add the testing samples of a class to testing dataframe

dataframeTrain = dataframeTrain.sample(frac=1)  #Randomly shuffle traing sampels
dataframeTest = dataframeTest.sample(frac=1) #Randomly shuffle test samples

trainingData = np.array(dataframeTrain) #Convert training data to a numpy array
testingData = np.array(dataframeTest)   #Convert test data to a numpy array

train_X = (trainingData[:,0:200]).astype(np.float64) #Extract features only of training data
train_Y = (trainingData[:,200]) #Extract class lables Y of training data
test_X = (testingData[:,0:200]).astype(np.float64) #Extract featrues only of testing data
test_Y = (testingData[:,200]) #Extract class labels Y of testing data

test_X = np.insert(test_X,[0],[1],axis=1) #insert ones at first column for intercept use

trainSamples = len(train_X[:,0]) #No of samples in training matrix
const1 = alpha/trainSamples #alpha / m for gradient descent equation

train_X = np.insert(train_X,[0],[1],axis=1) #insert ones at first column for intercept use
oneHotMat = np.zeros((trainSamples,noOfClasses)) #Create empty matrix for one hot encoding
vectOnes = np.ones((1,noOfClasses)) #Vector of ones to be used for gradient descent vectorized equation

for i in range(trainSamples): #One hot encode the labels matrix
    oneHotMat[i,((int)(train_Y[i])-1)] = 1

hypoTheta = np.zeros((len(train_X[0,:]),16)) #Declare empty matrix for storing values of hypotheses theta

for i in range(n_iterations_gd): #Run loop for gradient descent
    H2 = np.exp(np.matmul(train_X,hypoTheta)) #Intermediate vectrized matrix for gradient descent equation
    I = np.reciprocal(np.matmul(H2,vectOnes.T)) #Intermediate vectrized matrix for gradient descent equation
    E = np.multiply(H2,np.matmul(I,vectOnes)) #Intermediate vectrized matrix for gradient descent equation
    C = oneHotMat - E #Intermediate vectrized matrix for gradient descent equation
    D = np.matmul(train_X.T,C) #Intermediate vectrized matrix for gradient descent equation
    hypoTheta = hypoTheta + (const1)*D #Gradient descent equation

matA = np.exp(np.matmul(test_X,hypoTheta)) #e^theta_i.xi values matrix for predicting class
matSum = np.matmul(matA,vectOnes.T) #Summation of e^theta_j.xi values matrix for predicting class
predictedY = (np.argmax(matA/matSum,axis=1)+1).astype(int) #evalues class probabilities
test_Y = test_Y.astype(int)  #typecast obtained class labels for comparing

print("Obtained Accuracy of Softmax Classifier is : %d%%"%(((np.mean(test_Y==predictedY))*100)+1))#Round off and print the obtained accuracy





